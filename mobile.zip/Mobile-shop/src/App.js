
import {BrowserRouter} from 'react-router-dom';
import AppRoutes from './Components/Route';

import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
 

  return (
   <>
   <BrowserRouter>
   
   <AppRoutes/>
   
   </BrowserRouter>
   </>
  );
}

export default App;
