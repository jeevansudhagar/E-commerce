import React, { useState, useEffect } from 'react';
import { MdLocalShipping } from 'react-icons/md';
import { IoSearch } from "react-icons/io5";
import { LuLogIn } from "react-icons/lu";
import { BiLogOut } from "react-icons/bi";
import { FaRegUser } from "react-icons/fa6";
import { Link, useNavigate } from 'react-router-dom';
import './Nav.css';
import logo from '../Assets/logo.png';

const Nav = () => {
    const navigate = useNavigate();
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [userData, setUserData] = useState(null);

    useEffect(() => {
        // Check if user is already logged in (using localStorage/sessionStorage)
        const user = JSON.parse(localStorage.getItem("user"));
        if (user) {
            setIsAuthenticated(true);
            setUserData(user);
        }
    }, []);

    const handleAuthAction = () => {
        if (isAuthenticated) {
            // Logout logic
            localStorage.removeItem("user");
            setIsAuthenticated(false);
            setUserData(null);
            navigate('/login'); // Redirect to login page after logout
        } else {
            navigate('/login'); // Redirect to login page
        }
    };

    return (
        <div className="header">
            <div className="top-header">
                <div className="icon">
                    <MdLocalShipping />
                </div>
                <div className="info">
                    <p>Free Shipping When Shopping up to $1000</p>
                </div>
            </div>

            <div className="mid-header">
                <div className="logo">
                    <img src={logo} alt="Logo" />
                </div>
                <div className="search-box">
                    <input type="text" placeholder="Search" />
                    <button><IoSearch /></button>
                </div>
                <div className="user">
                    <div className="icon">
                        {isAuthenticated ? <BiLogOut /> : <LuLogIn />}
                    </div>
                    <div className="btn">
                        <button onClick={handleAuthAction}>
                            {isAuthenticated ? 'Logout' : 'Login'}
                        </button>
                    </div>
                </div>
            </div>

            <div className='last-header'> 
                <div className='user-profile'>
                    {isAuthenticated ? (
                        <>
                            <div className='icon'>
                                <FaRegUser />
                            </div>
                            <div className='info'>
                                <h2>{userData?.name}</h2>
                                <p>{userData?.email}</p>
                            </div>
                        </>
                    ) : (
                        <>
                            <div className='icon'>
                                <FaRegUser />
                            </div>
                            <div className='info'>
                                <p>Please login</p>
                            </div>
                        </>
                    )}
                </div>

                <div className='nav'>
                    <ul>
                        <li><Link to='/' className='link'>Home</Link></li>
                        <li><Link to='/Shop' className='link'>Shop</Link></li>
                        {/* <li><Link to='/collection' className='link'>Collection</Link></li> */}
                        <li><Link to='/cart' className='link'>Cart</Link></li>
                        <li><Link to='/Contact' className='link'>Contact</Link></li>
                    </ul>
                </div>

                <div className='offer'>
                    <p>Flat 10% off on all iPhones</p>
                </div>
            </div>
        </div>
    );
}

export default Nav;
