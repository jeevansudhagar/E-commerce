import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import axios from "axios";

const Dashboard = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    axios.get("http://127.0.0.1:5000/profile", { withCredentials: true })
      .then(response => setUser(response.data))
      .catch(() => setUser(null));
  }, []);

  if (user === null) {
    return <Navigate to="/login" />;
  }

  return <h1>Welcome {user.name}!</h1>;
};

export default Dashboard;
