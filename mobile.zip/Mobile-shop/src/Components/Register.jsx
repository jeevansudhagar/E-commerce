import React, { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./Register.css"; // Importing the external CSS file

const Register = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirm_password: "",
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Handle input changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirm_password) {
      setError("Passwords do not match");
      return;
    }

    try {
      const response = await axios.post("http://127.0.0.1:5000/register", {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        confirmPassword: formData.confirm_password,
      });

      if (response.status === 201) {
        setSuccess("Registration successful!");
        setError("");
        setFormData({ name: "", email: "", password: "", confirm_password: "" });
      }
    } catch (error) {
      setError(error.response?.data?.error || "Registration failed");
    }
  };

  return (
    <section className="register-container">
      <form onSubmit={handleSubmit} className="register-form">
        <h3>Register</h3>

        {error && <p className="error-text">{error}</p>}
        {success && <p className="success-text">{success}</p>}

        <div className="input-group">
          <label htmlFor="name">Name:</label>
          <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required />
        </div>

        <div className="input-group">
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
        </div>

        <div className="input-group">
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" value={formData.password} onChange={handleChange} required />
        </div>

        <div className="input-group">
          <label htmlFor="confirm_password">Confirm Password:</label>
          <input type="password" id="confirm_password" name="confirm_password" value={formData.confirm_password} onChange={handleChange} required />
        </div>

        <div className="button-container">
          <button type="submit" className="register-button">Register</button>
        </div>

        <h5>Already have an account? <Link to="/login">Login</Link></h5>
      </form>
    </section>
  );
};

export default Register;
