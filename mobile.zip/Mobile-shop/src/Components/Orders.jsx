import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

const API_BASE_URL = "http://localhost:5000";

function Orders() {
  const { userId } = useParams();
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    axios.get(`${API_BASE_URL}/orders/${userId}`)
      .then(response => {
        setOrders(response.data);
      })
      .catch(error => {
        console.error("Error fetching orders:", error);
      });
  }, [userId]);

  return (
    <div style={{ 
        padding: "20px", 
        maxWidth: "600px", 
        margin: "auto", 
        textAlign: "center", 
        background: "#f0f5ff", 
        borderRadius: "12px", 
        boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.1)" 
      }}>
        <h2 style={{ color: "#333", marginBottom: "20px", fontFamily: "Arial, sans-serif" }}>🛒 Your Orders</h2>
      
        {orders.length === 0 ? (
          <p style={{ fontSize: "18px", color: "#ff4f4f", fontWeight: "bold" }}>No orders found.</p>
        ) : (
          <ul style={{ listStyle: "none", padding: "0" }}>
            {orders.map(order => (
              <li 
                key={order.id} 
                style={{ 
                  border: "1px solid #ddd", 
                  padding: "15px", 
                  marginBottom: "15px", 
                  borderRadius: "10px", 
                  background: "#fff", 
                  transition: "transform 0.2s ease-in-out, background 0.3s" 
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = "#e6f7ff";  
                  e.currentTarget.style.transform = "scale(1.02)";
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = "#fff";  
                  e.currentTarget.style.transform = "scale(1)";
                }}
              >
                <p style={{ fontSize: "16px", fontWeight: "bold", color: "#444", marginBottom: "5px" }}>📦 Order ID: {order.id}</p>
                <p style={{ fontSize: "14px", color: "#666", marginBottom: "5px" }}>
                  <strong>Total Amount:</strong> ₹{order.totalAmount}
                </p>
                <p style={{ 
                  fontSize: "14px", 
                  fontWeight: "bold",
                  color: order.status === "Completed" ? "green" : "orange" 
                }}>
                  <strong>Status:</strong> {order.status}
                </p>
                <Link to={`/order/${order.id}`}>
                  <button 
                    style={{ 
                      marginTop: "10px", 
                      padding: "10px 20px", 
                      background: "#4CAF50", 
                      color: "white", 
                      border: "none", 
                      borderRadius: "8px", 
                      cursor: "pointer", 
                      fontWeight: "bold",
                      transition: "background 0.3s, transform 0.2s ease-in-out" 
                    }}
                    onMouseOver={(e) => {
                      e.target.style.background = "#45a049"; 
                      e.target.style.transform = "scale(1.05)";
                    }}
                    onMouseOut={(e) => {
                      e.target.style.background = "#4CAF50"; 
                      e.target.style.transform = "scale(1)";
                    }}
                  >
                    🔍 View Details
                  </button>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
      

  );
}

export default Orders;
