import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import './Login.css';


const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://127.0.0.1:5000/login", formData, { withCredentials: true });

      if (response.status === 200) {
        const userId = response.data.user.id;
        console.log(userId);
        localStorage.setItem("user", JSON.stringify(response.data.user));
        navigate(`/home/${userId}`);
      }
    } catch (error) {
      setError(error.response?.data?.error || "Invalid credentials");
    }
  };

  return (
    <section className="login-container">
      <form onSubmit={handleSubmit} className="login-form">
        <h3>Login</h3>

        {error && <p className="error-text">{error}</p>}

        <div className="input-group">
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
        </div>

        <div className="input-group">
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" value={formData.password} onChange={handleChange} required />
        </div>

        <div className="button-container">
          <button type="submit" className="login-button">Login</button>
        </div>

        <h5>Don't have an account? <Link to="/register">Register</Link></h5>
      </form>
    </section>
  );
};

export default Login;
