import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./Home";
import Shop from "./Shop";
import Collection from "./Collection";
import Contact from "./Contact";
import Login from "./Login";
import Register from "./Register";
import Admin from "./Admin";
import Dashboard from "./Dashboard";
import Logout from "./Logout";
import Cart from "./Cart";
import Orders from "./Orders"; // Import Orders Page
import OrderDetails from "./OrderDetails"; // Import Order Details Page

function AppRoutes() {
  const [cart, setCart] = useState([]);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const storedUserId = localStorage.getItem("userId");
    if (storedUserId) {
      setUserId(storedUserId);
    }
  }, []);

  const addToCart = (product) => {
    setCart([...cart, product]);
    console.log("Added to Cart:", product);
  };

  return (
    <Routes>
      {/* Authentication Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/logout" element={<Logout />} />

      {/* Admin Routes */}
      <Route path="/admin" element={<Admin />} />
      <Route path="/dashboard" element={<Dashboard />} />

      {/* Main Routes */}
      <Route path="/" element={<Home addToCart={addToCart} />} />
      <Route path="/home/:userId" element={<Home addToCart={addToCart} />} />
      <Route path="/shop" element={<Shop addToCart={addToCart} />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/collection" element={<Collection />}></Route>
      <Route path="/collection/:productId/:userId" element={<Collection userId={userId} addToCart={addToCart} />} />
      <Route path="/cart/:userId" element={<Cart />} />
      <Route path="/cart" element={<Cart/>}></Route>

      {/* Order Routes */}
      <Route path="/orders/:userId" element={<Orders />} />
      <Route path="/order/:orderId" element={<OrderDetails />} />
    </Routes>
  );
}

export default AppRoutes;
