import React, { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const API_BASE_URL = "http://localhost:5000";

function Cart() {
  const { userId: routeUserId } = useParams();
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState(routeUserId || null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!userId) {
      const storedUser = localStorage.getItem("user");
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        setUserId(parsedUser.id);
      }
    }
  }, []);

  useEffect(() => {
    if (!userId) return;

    setLoading(true);
    axios
      .get(`${API_BASE_URL}/cart/${userId}`)
      .then((response) => {
        setCart(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching cart:", error);
        setLoading(false);
      });
  }, [userId]);

  const removeFromCart = async (productId) => {
    try {
      await axios.delete(`${API_BASE_URL}/cart/${userId}/${productId}`);
      setCart(cart.filter((item) => item.productId !== productId));
    } catch (error) {
      console.error("Error removing product:", error);
    }
  };

  const totalPrice = cart.reduce(
    (acc, item) => acc + (item.Product?.price || 0) * item.quantity,
    0
  );

  const placeOrder = async () => {
    if (cart.length === 0) {
      alert("Your cart is empty. Add some products first.");
      return;
    }

    try {
      const response = await axios.post(`${API_BASE_URL}/order`, {
        userId,
        cartItems: cart, 
        totalAmount: totalPrice,
      });

      alert("Order placed successfully!");
      setCart([]);
      navigate(`/orders/${userId}`); 
    } catch (error) {
      console.error("Error placing order:", error);
      alert("Failed to place order. Please try again.");
    }
  };

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "auto", textAlign: "center" }}>
    <h2 style={{ color: "#333", marginBottom: "20px" }}>Your Cart</h2>
  
    {userId && <p style={{ fontSize: "16px", fontWeight: "bold" }}>User ID: {userId}</p>}
    
  
  
    {loading ? (
      <p style={{ fontSize: "18px", color: "#666" }}>Loading...</p>
    ) : cart.length === 0 ? (
      <p style={{ fontSize: "18px", color: "#ff4f4f" }}>Cart is empty.</p>
    ) : (
      <>
        {cart.map((item) => (
          <div 
            key={item.productId} 
            style={{ 
              border: "1px solid #ddd", 
              padding: "15px", 
              marginBottom: "15px", 
              borderRadius: "8px", 
              boxShadow: "2px 2px 10px rgba(0, 0, 0, 0.1)" 
            }}
          >
            <h3 style={{ color: "#444" }}>{item.Product ? item.Product.title : "Unknown Product"}</h3>
            <p><strong>Price:</strong> ₹{item.Product ? item.Product.price : "N/A"}</p>
            <p><strong>Quantity:</strong> {item.quantity}</p>
            <p><strong>Subtotal:</strong> ₹{(item.Product?.price || 0) * item.quantity}</p>
            <button 
              onClick={() => removeFromCart(item.productId)} 
              style={{ 
                background: "#ff4f4f", 
                color: "white", 
                padding: "8px 12px", 
                border: "none", 
                borderRadius: "5px", 
                cursor: "pointer", 
                transition: "background 0.3s" 
              }}
              onMouseOver={(e) => (e.target.style.background = "#e63946")}
              onMouseOut={(e) => (e.target.style.background = "#ff4f4f")}
            >
              Remove
            </button>
          </div>
        ))}
        
        <h3 style={{ color: "#2c3e50", marginTop: "20px" }}>Total Price: ₹{totalPrice}</h3>
  
        {/* Place Order Button */}
        <button 
          onClick={placeOrder} 
          style={{ 
            marginTop: "15px", 
            padding: "12px 20px", 
            background: "#007bff", 
            color: "white", 
            border: "none", 
            borderRadius: "5px", 
            cursor: "pointer", 
            transition: "background 0.3s" 
          }}
          onMouseOver={(e) => (e.target.style.background = "#0056b3")}
          onMouseOut={(e) => (e.target.style.background = "#007bff")}
        >
          Place Order
        </button>
      </>
    )}
  
    {/* Continue Shopping Button */}
    <Link to="/shop">
      <button 
        style={{ 
          marginTop: "15px", 
          padding: "12px 20px", 
          background: "#28a745", 
          color: "white", 
          border: "none", 
          borderRadius: "5px", 
          cursor: "pointer", 
          transition: "background 0.3s" 
        }}
        onMouseOver={(e) => (e.target.style.background = "#218838")}
        onMouseOut={(e) => (e.target.style.background = "#28a745")}
      >
        Continue Shopping
      </button>
    </Link>
  </div>
  
  );
}

export default Cart;
