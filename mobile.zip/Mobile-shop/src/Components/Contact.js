import React, { useState } from 'react';
import axios from 'axios';
import '../Components/Contact.css';
import Nav from './Nav';
import Footer from './Footer';

function Contact() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5000/send-email', formData);
            alert(response.data.message);
            setFormData({ name: '', email: '', subject: '', message: '' }); // Reset form
        } catch (error) {
            alert('Failed to send message. Try again later.');
        }
    };

    return (
        <>
            <Nav />
            <div className='contact'>
                <div className='container'>
                    <div className='form'>
                        <h2>#Contact us</h2>
                        <form onSubmit={handleSubmit}>
                            <div className='box1'>
                                <div className='label'><h4>Name</h4></div>
                                <div className='input'>
                                    <input type='text' name='name' value={formData.name} onChange={handleChange} placeholder='Name' required />
                                </div>
                            </div>
                            <div className='box1'>
                                <div className='label'><h4>E-mail</h4></div>
                                <div className='input'>
                                    <input type='email' name='email' value={formData.email} onChange={handleChange} placeholder='e-mail' required />
                                </div>
                            </div>
                            <div className='box1'>
                                <div className='label'><h4>Subject</h4></div>
                                <div className='input'>
                                    <input type='text' name='subject' value={formData.subject} onChange={handleChange} placeholder='subject' required />
                                </div>
                            </div>
                            <div className='box1'>
                                <div className='label'><h4>Message</h4></div>
                                <div className='input'>
                                    <textarea name='message' value={formData.message} onChange={handleChange} placeholder='message !' required></textarea>
                                </div>
                            </div>
                            <button className='sub-btn' type='submit'>Submit</button>
                        </form>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default Contact;
