import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import "../Components/Collection.css";
import Nav from "./Nav";
import Footer from "./Footer";

const API_BASE_URL = "http://localhost:5000"; // Backend URL

function Collection() {
  const { productId } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [userId, setUserId] = useState(null);
  const [user, setUser] = useState(null); // 🔹 Store user details

  // 🔹 Always fetch user data from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUserId(parsedUser.id);
      setUser(parsedUser); // Store user details
    } else {
      setUserId(null);
      setUser(null);
    }
  }, []);

  useEffect(() => {
    axios.get(`${API_BASE_URL}/products/${productId}`)
      .then((response) => {
        setProduct(response.data);
        setLoading(false);
      })
      .catch(() => {
        setError("Product not found.");
        setLoading(false);
      });
  }, [productId]);

  console.log("UserID:", userId, "ProductID:", productId, "User:", user);

  const addToCart = async () => {
    if (!userId) {
      alert("Please log in to add items to your cart.");
      navigate("/login");
      return;
    }

    try {
      await axios.post(`${API_BASE_URL}/cart`, { userId, productId, quantity: 1 });

      alert("Product added to cart!");
      navigate(`/cart/${userId}`);
    } catch (error) {
      console.error("Failed to add to cart:", error.response?.data || error.message);
      alert(`Error: ${error.response?.data?.message || "Could not add product to cart."}`);
    }
  };

  return (
    <>
      <Nav />
      <div className="cart">
        <div className="container">
          {/* 🔹 Display user info if logged in */}
          {user && (
            <div className="user-info">
              <h3>Welcome, {user.name}!</h3>
              <p>Email: {user.email}</p>
            </div>
          )}

          {loading ? (
            <p>Loading product details...</p>
          ) : error ? (
            <div className="empty-cart">
              <h3>#Selected Home Product</h3>
              <h2>{error}</h2>
              <Link to="/shop">
                <button>Shop Now</button>
              </Link>
            </div>
          ) : (
            <div className="product-details">
              <h3>#Product Details</h3>
              <img src={product.image || "/placeholder.jpg"} alt={product.title} />
              <h2>{product.title}</h2>
              <p>₹{product.price}</p>
              <p>{product.description}</p>
              <button
  onClick={addToCart}
  style={{
    backgroundColor: "#ff6b6b", // Red shade
    color: "white",
    padding: "10px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
    marginRight: "10px",
    transition: "background-color 0.3s",
  }}
  onMouseOver={(e) => (e.target.style.backgroundColor = "#ff4f4f")}
  onMouseOut={(e) => (e.target.style.backgroundColor = "#ff6b6b")}
>
  Buy
</button>

<Link to="/shop">
  <button
    style={{
      backgroundColor: "#4CAF50", // Green shade
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
      transition: "background-color 0.3s",
    }}
    onMouseOver={(e) => (e.target.style.backgroundColor = "#45a049")}
    onMouseOut={(e) => (e.target.style.backgroundColor = "#4CAF50")}
  >
    Continue Shopping
  </button>
</Link>

            </div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}

export default Collection;
