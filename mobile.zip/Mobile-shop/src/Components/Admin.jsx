import React, { useState, useEffect } from "react";
import axios from "axios";

const Admin = () => {
  const [product, setProduct] = useState({ title: "", price: "", image: null });
  const [products, setProducts] = useState([]);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:5000/products");
      setProducts(response.data);
    } catch (error) {
      console.error("❌ Error fetching products:", error);
    }
  };

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    setProduct({ ...product, image: e.target.files[0] });
  };

  // Add New Product
  const handleAddProduct = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("title", product.title);
    formData.append("price", product.price);
    formData.append("image", product.image);

    console.log("📤 Sending FormData:");
    for (let pair of formData.entries()) {
      console.log(pair[0], pair[1]);
    }

    try {
      await axios.post("http://127.0.0.1:5000/admin", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("✅ Product Added Successfully!");
      setProduct({ title: "", price: "", image: null });
      fetchProducts();
    } catch (error) {
      console.error("❌ Error adding product:", error);
      alert("❌ Error adding product");
    }
  };

  // Edit Product
  const handleEditProduct = async (e) => {
    e.preventDefault();
    if (!editingId) return;

    const formData = new FormData();
    formData.append("title", product.title);
    formData.append("price", product.price);
    if (product.image) {
      formData.append("image", product.image);
    }

    console.log("📤 Editing FormData:");
    for (let pair of formData.entries()) {
      console.log(pair[0], pair[1]);
    }

    try {
      await axios.put(`http://127.0.0.1:5000/products/${editingId}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("✅ Product Updated Successfully!");
      setProduct({ title: "", price: "", image: null });
      setEditingId(null);
      fetchProducts();
    } catch (error) {
      console.error("❌ Error updating product:", error);
      alert("❌ Error updating product");
    }
  };

  // Delete Product
  const handleDeleteProduct = async (id) => {
    try {
      await axios.delete(`http://127.0.0.1:5000/products/${id}`);
      alert("✅ Product Deleted Successfully!");
      fetchProducts();
    } catch (error) {
      console.error("❌ Error deleting product:", error);
      alert("❌ Error deleting product");
    }
  };

  return (
    <div style={{ maxWidth: "600px", margin: "50px auto", textAlign: "center", backgroundColor: "rgb(235, 209, 220)", padding: "20px", borderRadius: "8px", boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)" }}>
      <h2 style={{ color: "#333", fontSize: "24px" }}>{editingId ? "✏️ Edit Product" : "➕ Add New Product"}</h2>
      <form onSubmit={editingId ? handleEditProduct : handleAddProduct} style={{ marginBottom: "20px" }}>
        <input type="text" name="title" value={product.title} onChange={handleChange} placeholder="Title" required style={{ width: "100%", padding: "10px", marginBottom: "10px", borderRadius: "4px", border: "1px solid #ddd" }} />
        <input type="number" name="price" value={product.price} onChange={handleChange} placeholder="Price" required style={{ width: "100%", padding: "10px", marginBottom: "10px", borderRadius: "4px", border: "1px solid #ddd" }} />
        <input type="file" name="image" onChange={handleImageChange} accept="image/*" required={!editingId} />
        <button type="submit" style={{ width: "100%", padding: "10px", backgroundColor: "#f52679", color: "white", borderRadius: "4px", border: "none", fontSize: "16px" }}>{editingId ? "💾 Save Changes" : "🚀 Add Product"}</button>
      </form>
      <h2 style={{ color: "#333", fontSize: "20px", marginTop: "30px" }}>📦 Product List</h2>
      <ul style={{ listStyleType: "none", padding: "0" }}>
        {products.map((p) => (
          <li key={p.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px", borderBottom: "1px solid #ddd" }}>
            <img src={p.image} alt={p.title} width="50" style={{ borderRadius: "4px" }} />
            <span>{p.title} - ₹{p.price}</span>
            <div>
              <button onClick={() => { setProduct({ title: p.title, price: p.price, image: null }); setEditingId(p.id); }} style={{ background: "none", border: "none", color: "#4CAF50", cursor: "pointer", marginRight: "10px" }}>✏️ Edit</button>
              <button onClick={() => handleDeleteProduct(p.id)} style={{ background: "none", border: "none", color: "#F44336", cursor: "pointer" }}>🗑️ Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Admin;