// const Homeproduct = [
//     {
//       id: 1,
//       title: 'airpods',
//       price: '26',
//       Image: require('../Assets/airbuds.png'),
//       cat: 'airpod',
//       type: 'new',
//     },
//     {
//       id: 2,
//       title: 'iphone 13 pro',
//       price: '65',
//       Image: require('../Assets/iphone.png'),
//       cat: 'iphone',
//       type: 'new',
//     },
//     {
//       id: 3,
//       title: 'iMac',
//       price: '54',
//       Image: require('../Assets/monitor.png'),
//       cat: 'imac',
//       type: 'new',
//     },
//     {
//       id: 4,
//       title: 'homepod',
//       price: '296',
//       Image: require('../Assets/speaker.png'),
//       cat: 'homepod',
//       type: 'featured',
//     },
//     {
//       id: 5,
//       title: 'apple tv 4k',
//       price: '256',
//       Image: require('../Assets/tv.png'),
//       cat: 'tv',
//       type: 'featured',
//     },
//     {
//       id: 6,
//       title: 'macbook pro',
//       price: '276',
//       Image: require('../Assets/MQDP3.png'),
//       cat: 'macbook',
//       type: 'featured',
//     },
//     {
//       id: 7,
//       title: 'iphone 14 pro max',
//       price: '264',
//       Image: require('../Assets/MCFM4.png'),
//       cat: 'iphone',
//       type: 'top',
//     },
//     {
//       id: 8,
//       title: 'charger 20w',
//       price: '267',
//       Image: require('../Assets/charger.png'),
//       cat: 'charger',
//       type: 'top',
//     },
//   ];
  
//   export default Homeproduct;
  
