import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

const API_BASE_URL = "http://localhost:5000";

function OrderDetails() {
  const { orderId } = useParams();
  const [orderItems, setOrderItems] = useState([]);

  useEffect(() => {
    axios.get(`${API_BASE_URL}/order-items/${orderId}`)
      .then(response => {
        setOrderItems(response.data);
      })
      .catch(error => {
        console.error("Error fetching order items:", error);
      });
  }, [orderId]);

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "auto", textAlign: "center", background: "#f8f9fa", borderRadius: "8px", boxShadow: "2px 2px 10px rgba(0, 0, 0, 0.1)" }}>
    <h2 style={{ color: "#2c3e50", marginBottom: "20px" }}>Order Details (ID: {orderId})</h2>
  
    {orderItems.length === 0 ? (
      <p style={{ fontSize: "18px", color: "#ff4f4f" }}>No items found for this order.</p>
    ) : (
      <ul style={{ listStyle: "none", padding: "0" }}>
        {orderItems.map(item => (
          <li 
            key={item.id} 
            style={{ 
              border: "1px solid #ddd", 
              padding: "15px", 
              marginBottom: "15px", 
              borderRadius: "8px", 
              background: "#fff", 
              transition: "background 0.3s" 
            }}
            onMouseOver={(e) => (e.target.style.background = "#e3f2fd")}
            onMouseOut={(e) => (e.target.style.background = "#fff")}
          >
            <p style={{ fontSize: "16px", fontWeight: "bold", color: "#444" }}>Product ID: {item.productId}</p>
            <p style={{ fontSize: "14px", color: "#555" }}><strong>Price:</strong> ₹{item.price}</p>
            <p style={{ fontSize: "14px", color: "#555" }}><strong>Quantity:</strong> {item.quantity}</p>
          </li>
        ))}
      </ul>
    )}
  </div>
  
  );
}

export default OrderDetails;
