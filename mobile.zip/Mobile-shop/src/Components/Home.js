import React, { useState, useEffect } from "react";
import { Link, useNavigate} from "react-router-dom";
import axios from "axios";
import { FaEye, FaHeart } from "react-icons/fa";

import { FaFacebookF, FaTwitter, FaInstagram, FaYoutube } from "react-icons/fa";
import testimonial from '../Assets/testimonial.jpeg';
import Nav from "./Nav";
import Footer from "./Footer";
import './Home.css';
import { useParams } from "react-router-dom";
const API_BASE_URL = "http://localhost:5000"; // Backend URL

// function Home({ addToCart }) {
//   const { userId } = useParams(); // Get userId from the route params
//   const [products, setProducts] = useState([]);
//   const navigate = useNavigate();

//   // Fetch products from backend
//   useEffect(() => {
//     axios
//       .get(`${API_BASE_URL}/products`)
//       .then((response) => setProducts(response.data))
//       .catch((error) => console.error("Error fetching products:", error));
//   }, []);

//   return (
//     <>
//       <Nav />
//       <div className="home">
//         <div className="top-banner">
//           <div className="contant">
//             <h3>Your new iPhone 14.<br /></h3>
//             <h2>Just the way you <br />want it...</h2>
//             <p>30% off at your first order</p>
//             <Link to={`/Shop/${userId}`} className="link">Shop Now</Link>
//           </div>
//         </div>
//         <div className="products">
//           <div
//             className="container"
//             style={{
//               display: "flex",
//               flexDirection: "row",
//               flexWrap: "wrap",
//               gap: "20px",
//               justifyContent: "center",
//             }}
//           >
//             {products.length > 0 ? (
//               products.map((product) => (
//                 <div
//                   key={product.id}
//                   className="box"
//                   style={{
//                     display: "flex",
//                     flexDirection: "column",
//                     alignItems: "center",
//                     width: "250px",
//                     padding: "10px",
//                     border: "1px solid #ddd",
//                     borderRadius: "10px",
//                   }}
//                 >
//                   <div className="img-box">
//                     {/* ✅ Fix Image URL */}
//                     <img
//                       src={product.image ? product.image : "/placeholder.jpg"} // Default image fallback
//                       alt={product.title}
//                       style={{ width: "100%", height: "200px", objectFit: "cover", borderRadius: "10px" }}
//                     />
//                     <div
//                       className="icon"
//                       style={{ display: "flex", gap: "10px", marginTop: "5px" }}
//                     >
//                       <div className="icon-box"><FaEye /></div>
//                       <div className="icon-box"><FaHeart /></div>
//                     </div>
//                   </div>

//                   <div className="info" style={{ textAlign: "center" }}>
//                     <Link to={`/collection/${product.id}`}>
//                       <h2 style={{ fontSize: "18px" }}>{product.title}</h2>
//                       <p style={{ color: "#333", fontWeight: "bold" }}>₹{product.price}</p>
//                     </Link>
//                     <button
//                       onClick={() => {
//                         addToCart(product);
//                         navigate(`/collection/${product.id}`);
//                       }}
//                       style={{
//                         padding: "10px",
//                         background: "#cd1e76",
//                         color: "white",
//                         border: "none",
//                         borderRadius: "5px",
//                         cursor: "pointer",
//                         marginTop: "10px",
//                       }}
//                     >
//                       Add to Cart
//                     </button>
//                   </div>
//                 </div>
//               ))
//             ) : (
//               <p>Loading products...</p>
//             )}
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// }

function Home({ addToCart }) {

  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const { userId } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get(`${API_BASE_URL}/products`)
      .then((response) => {
        setProducts(response.data);
        setFilteredProducts(response.data);
        setLoading(false);
      })
      .catch((err) => {
        setError("Failed to fetch products.");
        setLoading(false);
      });
  }, []);

  const filterCategory = (category) => {
    const filtered = products.filter(product => product.type === category);
    setFilteredProducts(filtered);
  };

  const showAllProducts = () => {
    setFilteredProducts(products);
  };

  return (
    <>
      <Nav />
      <div className='home'>
      <div className="top-banner">
           <div className="contant">
             <h3>Your new iPhone 14.<br /></h3>
            <h2>Just the way you <br />want it...</h2>
            <p>30% off at your first order</p>
            <Link to={`/Shop`} className="link">Shop Now</Link>
          </div>
        </div>
        <div className='trending'>
          <div className='container'>
            <div className='left-box'>
              <div className='header'>
                <h2 onClick={showAllProducts}>Trending Products</h2>
                <div className='cate'>
                  <h3 onClick={() => filterCategory('new')}>NEW</h3>
                  <h3 onClick={() => filterCategory('featured')}>Featured</h3>
                  <h3 onClick={() => filterCategory('top')}>Top Selling</h3>
                </div>
              </div>

              <div className='products'>
                {loading ? (
                  <p>Loading products...</p>
                ) : error ? (
                  <p>{error}</p>
                ) : (
                  <div className='container'>
                    {filteredProducts.map((product) => (
                      <div key={product.id} className='box'>
                        <div className='img-box'>
                          <img src={product.image} alt={product.title} />
                          <div className='icon'>
                            <div className='icon-box'><FaEye /></div>
                            <div className='icon-box'><FaHeart /></div>
                          </div>
                        </div>
                        <div className="info">
                          <Link to={`/collection/${product.id}`}>
                            <h2>{product.title}</h2>
                            <p>₹{product.price}</p>
                          </Link>
                          <button onClick={() => { addToCart(product); navigate(`/collection/${product.id}/${userId}`); }}>
                            add to Cart
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className='right-box'>
              <div className='right-container'>
                <div className='testimonial'>
                  <h3>Our Testimonial</h3>
                  <div className='details'>
                    <div className='img-box'><img className='img-test' src={testimonial} alt='testimonial' /></div>
                    <div className='info'>
                      <h4>Jeevan Sudhagar</h4>
                      <h4>Web Designer</h4>
                      <p>Hey... all this is Jeeva from Madurai.</p>
                    </div>
                  </div>
                </div>

                <div className='newsletter'>
                  {/* <h3>Newsletter</h3> */}
                  <p>Join our mailing list</p>
                  <input type='email' placeholder='E-mail' autoComplete='off' />
                  <button>Subscribe</button>
                  <div className='icon-box'>
                    <a href='https://www.facebook.com' target='_blank' rel='noopener noreferrer' className='icon'><FaFacebookF /></a>
                    <a href='https://www.twitter.com' target='_blank' rel='noopener noreferrer' className='icon'><FaTwitter /></a>
                    <a href='https://www.instagram.com' target='_blank' rel='noopener noreferrer' className='icon'><FaInstagram /></a>
                    <a href='https://www.youtube.com' target='_blank' rel='noopener noreferrer' className='icon'><FaYoutube /></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>  
      <Footer />
    </>
  );
}

export default Home;
